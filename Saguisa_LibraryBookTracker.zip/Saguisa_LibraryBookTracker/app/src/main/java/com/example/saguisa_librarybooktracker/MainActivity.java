package com.example.saguisa_librarybooktracker;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    EditText bookCode, numDays;
    Button borrow;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //reference to ui elements
        find();

        borrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });
    }

    public void find(){
        bookCode = findViewById(R.id.editTextBookCode);
        numDays = findViewById(R.id.editTextNumDays);
        borrow = findViewById(R.id.buttonBorrow);
    }
}