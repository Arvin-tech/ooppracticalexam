package com.example.saguisa_librarybooktracker;

public class PremiumBook extends Books{

    @Override
    public void computeCost(){

    }
}
