package com.example.saguisa_librarybooktracker;

public abstract class Books {
    private String bookCode;
    private String title;
    private String author;
    private int num_of_Days;
    private boolean isBorrowed = true;

    public abstract void computeCost();
}
