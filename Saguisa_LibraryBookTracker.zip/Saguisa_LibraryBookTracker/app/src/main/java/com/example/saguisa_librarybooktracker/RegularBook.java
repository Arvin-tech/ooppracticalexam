package com.example.saguisa_librarybooktracker;

public class RegularBook extends Books{

    @Override
    public void computeCost() {

    }
}
