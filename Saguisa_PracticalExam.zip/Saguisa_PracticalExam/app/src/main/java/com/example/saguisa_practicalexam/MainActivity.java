package com.example.saguisa_practicalexam;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText loanAmountEditText;
    Button smallBanksButton, bigBanksButton;
    TextView outputTextView; //for interest
    Bank bank;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //reference
        findViewById();

        //initialize bank object
        bank = new Bank();

        //small bank button listener
        smallBanksButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                displaySmallBank(); //invoke method
            }
        });

        //big bank button listener
        bigBanksButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                displayBigBank(); //invoke method
            }
        });

    }

    public void findViewById(){
        loanAmountEditText = findViewById(R.id.LoanAmountEditText);
        smallBanksButton = findViewById(R.id.smallBankButton);
        bigBanksButton = findViewById(R.id.bigBankButton);
        outputTextView = findViewById(R.id.outputTextView);
    }

    public void displaySmallBank(){
        double loanAmount = Double.parseDouble(loanAmountEditText.getText().toString());
        bank = new SmallBank(loanAmount);
        double interest = bank.computeInterest();
        outputTextView.setText(String.format("Interest: $%.2f", interest));
    }

    public void displayBigBank(){
        double loanAmount = Double.parseDouble(loanAmountEditText.getText().toString());
        bank = new BigBank(loanAmount);
        double interest = bank.computeInterest();
        outputTextView.setText(String.format("Interest: $%.2f", interest));
    }

}