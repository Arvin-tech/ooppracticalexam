package com.example.saguisa_practicalexam;

public class BigBank extends Bank{
    private double interestRate;
    public BigBank(double loanAmount) {
        super(loanAmount);
        interestRate = 0.05;
    }
}
