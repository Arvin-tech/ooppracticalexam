package com.example.saguisa_practicalexam;

public class SmallBank extends Bank{
    private double interestRate;
    public SmallBank(double loanAmount) {
        super(loanAmount);
        interestRate = 0.03;
    }
}
