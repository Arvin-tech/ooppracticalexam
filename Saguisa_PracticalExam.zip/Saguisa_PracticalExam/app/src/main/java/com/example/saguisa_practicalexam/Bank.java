package com.example.saguisa_practicalexam;

public class Bank {
    private double loanAmount;
    private double interestRate;

    //default constructor
    public Bank(){
        loanAmount = 0;
        interestRate = 0;
    }

    //non-default constructor
    public Bank(double loanAmount){
        this.loanAmount = loanAmount;
        interestRate = 0.04;
    }

    public double computeInterest() {
        return loanAmount * (((Math.pow((1 + (interestRate / 12)), 2)) - 1));
    }

    public double returnInterest(){
        return computeInterest();
    }

    //accessors and mutators
    public double getInterestRate(){
        return interestRate;
    }

    public void setInterest(double interestRate){
        this.interestRate = interestRate;
    }


}


